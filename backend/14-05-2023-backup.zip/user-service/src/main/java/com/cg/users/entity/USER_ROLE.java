package com.cg.users.entity;

public enum USER_ROLE{
	ADMIN,
	USER
}